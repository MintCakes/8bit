/***********************************************************************
 * 实验名称：串口数据通信实验
 *
 * 实验准备：龙芯1C102开发板、TTL-串口模块、杜邦线
 *
 * 硬件接线：使用TTL-串口模块和杜邦线连接龙芯1C102开发板开发板与PC端
 *          TTL-串口模块--------龙芯1C102开发板开发板
 *             TXD      -------     GPIO_06
 *             RXD      -------     GPIO_07
 *             GND      -------      GND
 *
 * 实验现象：通过TTL-串口模块与PC端连接，实现数据自发自收。
 *          PC端使用串口助手软件，可以看到串口0接收到的数据。
 *          PC端发送数据到串口0，串口0接收到的数据。
 *
 * 注意事项：串口助手配置为115200波特率，8位数据位，无校验位，1位停止位。
 *          串口发送时，需要选择为HEX模式，否则会出现乱码。
 **************************************************************************/
#include "ls1x.h"
#include "Config.h"
#include "led.h"
#include "ls1x_gpio.h"
#include "ls1x_latimer.h"
#include "ls1c102_ptimer.h"
#include "ls1x_common.h"
#include "ls1x_gpio.h"
#include "ls1x_exti.h"
#include "ls1x_latimer.h"
#include "ls1x_rtc.h"
#include "ls1c102_touch.h"
#include "ls1x_string.h"
#include "ls1x_wdg.h"
#include "ls1x_uart.h"
#include "ls1x_spi.h"
#include "ls1c102_i2c.h"
#include "ls1x_uart.h"
#include "ls1x_clock.h"
#include "UserGpio.h"
#include "Config.h"
#include "oled.h"
#include "queue.h"
uint8_t received_data = 0;
// extern uint8_t buffer;
uint8_t flag;
uint8_t Read_Buffer0[DATA_LEN]; // 设置接收缓冲数组
uint8_t Read_Buffer2[DATA_LEN]; // 设置接收缓冲数组
uint8_t Read_length;
int main(int arg, char *args[])
{
    GPIOInit();        // io配置
    IIC_Init();
    OLED_Init();
    LED_Init();
    KEY_Init();
    BEEP_Init();    
	Queue_Init(&Circular_queue0);
	Queue_Init(&Circular_queue2);
    EnableInt(); // 开总中断
    // Uart0_init(9600); // 串口0初始化，io06 io07   串口初始化需要在开启EnableInt之后
	Uart1_init(115200);
	// Uart2_init(9600);	
    
    // OLED_Show_Str(0, 0, "串口数据通信实验", 16); // OLED显示界面
    // OLED_Show_Str(0, 3, "TX:", 16);              // OLED显示界面
    // OLED_Show_Str(0, 6, "RX:", 16);
    // UART_SendData(UART2,'0x33'); // 开始发送3  观察调试
    
    while (1)
    {   
        switch(KEY_Check())
        {
            case 1 : flag=1;
        }
        // if (Queue_isEmpty(&Circular_queue2) == 0) // 判断队列是否为空，即判断是否收到数据
        // {
        //     Read_length = Queue_HadUse(&Circular_queue2); // 返回队列中数据的长度
        //     memset(Read_Buffer2, 0, DATA_LEN);//填充接收缓冲区为0
        //     Queue_Read(&Circular_queue2, Read_Buffer2, Read_length); // 读取队列缓冲区的值到接收缓冲区
        //     OLED_Show_Str(0, 6, Read_Buffer2, 16);
        //     UART_SendData(UART2, Read_Buffer2);
        // }
        // else   
        // {
        //     memset(Read_Buffer2, 0, DATA_LEN); // 填充接收缓冲区为0
        // }

		if(flag==1)																// 发送初始化指令
		{			
            LED_On(LED1_PIN);
			UART_SendString(UART1, "\r\n");
			UART_SendString(UART1, "AT\r\n"); 								// 从串口2发送字符串
			delay_ms(500); 
			UART_SendString(UART1, "AT+CMGF=1\r\n"); 						// 设置短信格式为文本模式
			delay_ms(500);
			UART_SendString(UART1, "AT+CSCS=\"GSM\"\r\n"); 					// 设置字符集为 GSM
			delay_ms(500);
			UART_SendString(UART1, "AT+CMGS=\"19707054607\"\r\n");			// 设置接收短信的号码
			delay_ms(500);
			UART_SendString(UART1,"Your family needs help\r\n");						//设置发送内容
			delay_ms(500);
			UART_SendData(UART1,0x1a);										//结束发送
            flag=0;
		}
        LED_Off(LED1_PIN);


	}
    return 0;
}