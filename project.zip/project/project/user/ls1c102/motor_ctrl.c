#include "ls1x.h"
#include "Config.h"
#include "ls1x_gpio.h"
#include "ls1x_latimer.h"
#include "ls1c102_ptimer.h"
#include "ls1x_common.h"
#include "ls1x_gpio.h"
#include "ls1x_exti.h"
#include "ls1x_latimer.h"
#include "ls1x_rtc.h"
#include "ls1c102_touch.h"
#include "ls1x_string.h"
#include "ls1x_wdg.h"
#include "ls1x_uart.h"
#include "ls1x_spi.h"
#include "ls1c102_i2c.h"
#include "ls1x_uart.h"
#include "ls1x_clock.h"
#include "UserGpio.h"
#include "Config.h"
#include "oled.h"
#include "BEEP.h"
#include "queue.h"
#include "motor_ctrl.h"

void Motor_ctrl_Init(char *frequency1,char *frequency2,char *frequency3)
{
    UART_SendString(UART0,frequency1);
    //OLED_Show_Str(0,0,frequency1,16);
    UART_SendString(UART1,frequency2);
    //OLED_Show_Str(0,4,frequency2,16);
    UART_SendString(UART1,frequency3);
    //OLED_Show_Str(70,4,frequency3,16);
}
/*
*   驱动电机，UART0连接三路pwm模块板,UART1连接两路pwm模块板
*   
*   duty 占空比  turn 正反转：1 正转；0 反转
*/
void Motor_Ctrl_L(int duty,short turn)
{

    if(turn==1)                       
    {
        char str1[20]="D10";
        char str[20];
        char str2[10]="D20";  
        strcat(str1,itoa(duty,str,10));
        strcat(str2,"00");
        UART_SendString(UART0,str1);
        //OLED_Show_Str(0,2,str1,16);
        UART_SendString(UART0,str2);
        //OLED_ShowString(40,2,str2,16);  
        
    }
    else if(turn==0)                  
    {
        char str1[20]="D10";
        char str[20];
        char str2[10]="D20";  
        strcat(str1,"00");
        strcat(str2,itoa(duty,str,10));
        UART_SendString(UART0,str1);
        //OLED_Show_Str(0,2,str1,16);
        UART_SendString(UART0,str2);
        //OLED_ShowString(40,2,str2,16);       
    }
}
void Motor_Ctrl_R(int duty,short turn)
{
    if(turn==1)                       
    {
        char str1[20]="dU1:0";
        char str[20];
        char str2[10]="D30";      
        strcat(str1,itoa(duty,str,10));
        strcat(str2,"00");
        UART_SendString(UART1,str1);
        //OLED_Show_Str(0,6,str1,16);
        UART_SendString(UART0,str2);
        // OLED_ShowString(80,2,str2,16);  
    }
    else if(turn==0)                  
    {
        char str1[20]="dU1:0";
        char str[20];
        char str2[10]="D30";       
        strcat(str1,itoa(duty,str,10));
        strcat(str2,"00");
        UART_SendString(UART1,str1);
        // OLED_Show_Str(0,6,str1,16);
        UART_SendString(UART0,str2);
        // OLED_ShowString(80,2,str2,16);    
    }
}
void Step_Motor_Ctrl(int duty)
{
        char str1[20]="dU2:0";
        char str[20];
        strcat(str1,itoa(duty,str,10));
        UART_SendString(UART1,str1);
        // OLED_Show_Str(60,6,str1,16);
}
int32_t pid_realize(int16_t expect,int input)
{
    static speedpid_struct pid_struct;
    double Kp_initial,Ki_initial,Kd_initial;
    pid_struct.Kp=Kp_initial;
    pid_struct.Ki=Ki_initial;
    pid_struct.Kd=Kd_initial;

    pid_struct.SetSpeed=expect;
    pid_struct.ActualSpeed=input;
    pid_struct.err=pid_struct.ActualSpeed-pid_struct.SetSpeed;
    pid_struct.integral+=pid_struct.err*pid_struct.Ki;
    pid_struct.speed=(int32_t)(pid_struct.Kp*pid_struct.err+pid_struct.Kd*(pid_struct.err-pid_struct.err_last)+pid_struct.Ki*pid_struct.integral);
    pid_struct.err_last=pid_struct.err;
    return pid_struct.speed;
}
