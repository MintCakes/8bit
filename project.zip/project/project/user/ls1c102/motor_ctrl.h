#ifndef __MOTOR_CTRL_H
#define __MOTOR_CTRL_H
typedef struct speedpid
{
    int32_t SetSpeed;
    int32_t ActualSpeed;
    int32_t err;
    int32_t err_last;
    int32_t integral;
    double Kp,Ki,Kd;
    int32_t speed;
}speedpid_struct;
void Motor_ctrl_Init(char *frequency1,char *frequency2,char *frequency3);
void Motor_Ctrl_L(int duty,short turn);
void Motor_Ctrl_R(int duty,short turn);
void Step_Motor_Ctrl(int duty);
int32_t pid_realize(int16_t expect,int input);


#endif // __KEY_H
