/***********************************************************************
 * 实验名称：智能车龙芯1c102主板
 *
 * 实验准备：龙芯1C102开发板、两路pwm模块、三路pwm模块
 *
 * 硬件接线：
 *              TX      -------     GPIO_06
 *              RX      -------     GPIO_07
 *              TXD     -------     GPIO_08
 *              RXD     -------     GPIO_09
 *              Trig    -------     GPIO_18
 *              Echo    -------     GPIO_19
 *              PWM1    -------     P1
 *              PWM2    -------     P2
 *              PWM3    -------     P4
 *              PW1     -------     P3
 *              PW2     -------     Step(白)
 *              5V      -------     Step(红)、VN+ *2、Vmcu、VCC(超声波)
 *              GND     -------     Step(黑)、VN- *2、Gnd(超声波)
 *              
 *
 * 注意事项：
 * 超声波使用原理：超声波有四个引脚，分别是VCC、Trig、Echo、GND（连线已在上文提到）
 * 程序开始后，每过100*1000us定时器将Trig拉直高电平（interrupt391-395）持续15us(main92-98)后拉低
 * 超声波模块收到后发送超声波
 * 一段时间后超声波接收，模块将Echo拉高，高电平时间与距离成正比。公式（main80）cm=us/58
 * 此时完成一次超声波收发。在81行将数据整理好，82-90处理数据，91行将us清零
 **************************************************************************/
#include "ls1x.h"
#include "Config.h"
#include "ls1x_gpio.h"
#include "ls1x_latimer.h"
#include "ls1c102_ptimer.h"
#include "ls1x_common.h"
#include "ls1x_gpio.h"
#include "ls1x_exti.h"
#include "ls1x_latimer.h"
#include "ls1x_rtc.h"
#include "ls1c102_touch.h"
#include "ls1x_string.h"
#include "ls1x_wdg.h"
#include "ls1x_uart.h"
#include "ls1x_spi.h"
#include "ls1c102_i2c.h"
#include "ls1x_uart.h"
#include "ls1x_clock.h"
#include "UserGpio.h"
#include "Config.h"
#include "oled.h"
#include "BEEP.h"
#include "queue.h"
#include "led.h"
#include "motor_ctrl.h"
#define Trig_PIN    GPIO_PIN_18
#define Echo_PIN    GPIO_PIN_19
extern int16_t Trig,Echo,Echo_flag,stop;
extern uint8_t beidou_rxd_flag,Uart0_buffer[100];
int16_t distance;
int main(int arg, char *args[])
{
    beidou_rxd_flag=0;
    //GPIOInit();         //io配置
    //KEY_init();         //按键初始化
    BEEP_Init();
    OLED_Init();        //OLED配置初始化
    EnableInt();        //开总中断
    timer_init(1);      //100us
    Queue_Init(&Circular_queue);
    stop=0;

    Uart0_init(9600);   // 串口0初始化，io06 io07   串口初始化需要在开启EnableInt之后
    // Uart1_init(9600);   // 串口1初始化，io08 io09   串口初始化需要在开启EnableInt之后
    gpio_write_pin(Trig_PIN,0);
    while(1)
    {
        if(gpio_get_pin(Echo_PIN))
        {
            Echo=1;
            
        }
        else if(Echo==1)
        {
            Echo=0;
            distance=(Echo_flag*100)/58;
            if(distance>=999) 
				distance=999;
                if(distance>80)
                    stop=1;
                else if(distance<=80)
                {
                    stop=0;
                }
            OLED_ShowInt32Num(0,0,distance,3,16);
            Echo_flag=0;
        }
        // gpio_write_pin(GPIO_PIN_40,0);
        // gpio_write_pin(GPIO_PIN_37,0);		
		
        if(Trig==1)
        {
            gpio_write_pin(Trig_PIN,1);
            delay_us(15);
            gpio_write_pin(Trig_PIN,0);
            Trig=0;
        }
    }
    return 0;
}