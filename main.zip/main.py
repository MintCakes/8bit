THRESHOLD = (100, 30, -128, 5, -7, 127) #暗物体的灰度阈值
import sensor, image, time
from pyb import LED, Servo
#import car
from pid import PID

rho_pid = PID(p=0.25, i=0)           #霍夫变换的ρ，代表中线y=ax+b的截距b
theta_pid = PID(p=0.001, i=0)       #霍夫变换的θ，代表中线y=ax+b的斜率a

LED(1).on()                         #摄像头补光 x3
LED(2).on()
LED(3).on()

sensor.reset()                      #初始化摄像头
sensor.set_pixformat(sensor.RGB565) #图像为彩图
sensor.set_framesize(sensor.QQQVGA) #分辨率 80x60 (4,800 pixels) - O(N^2) max = 2,3040,000.
#sensor.set_windowing([0,20,80,40])
sensor.skip_frames(time = 2000)     # WARNING: If you use QQVGA it may take seconds
clock = time.clock()                # to process a frame sometimes.
Servo(2).angle(0)

while(True):
    clock.tick()

    img = sensor.snapshot().binary([THRESHOLD])              #截取一张图片并对图片进行阈值分割

    line = img.get_regression([(100,100)], robust = True)    #快速线性回归☆

    if (line):
        rho_err = abs(line.rho())-img.width()/2              #得到的直线与中央线偏移的距离
        if line.theta()>90:
            theta_err = line.theta()-180
        else:
            theta_err = line.theta()                         #以上进行水平坐标变换
        img.draw_line(line.line(), color = 127)
        #print(rho_err,line.magnitude(),rho_err)
        if line.magnitude()>8:                               #直线的大小，越大越好
            #if -40<b_err<40 and -30<t_err<30:
            rho_output = rho_pid.get_pid(rho_err,1)          #pid运算
            theta_output = theta_pid.get_pid(theta_err,1)
            output = rho_output+theta_output
            # car.run(50+output, 50-output)
            Servo(2).angle(-output)
            print(output,rho_output,theta_output,rho_err,theta_err)
        else:
            # car.run(0,0)                                     #线性回归效果不好，车停
            Servo(2).angle(0)
    else:
        # car.run(50,-50)                                      #如果没找到线，原地旋转
        Servo(2).angle(0)
            pass
    #print(clock.fps())

